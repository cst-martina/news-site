const articles = [
  { id: 1, title: "Nuovo Governo in Italia", date: "26 Aprile 2025", image: "https://via.placeholder.com/600x400?text=Governo", content: "Il nuovo governo è stato approvato oggi..." },
  { id: 2, title: "Finale Champions League", date: "25 Aprile 2025", image: "https://via.placeholder.com/600x400?text=Champions", content: "Grande finale a Istanbul..." }
];

window.onload = function() {
  loadFeaturedArticle();
  loadArticles();
  updateDateTime();
};

function loadFeaturedArticle() {
  const featured = articles[0];
  const container = document.getElementById("featuredArticle");
  container.innerHTML = `
    <img src="${featured.image}" alt="${featured.title}">
    <h1>${featured.title}</h1>
    <p>${featured.content}</p>
  `;
}

function loadArticles() {
  const container = document.getElementById("articles");
  const latestList = document.getElementById("latestArticles");

  articles.forEach(article => {
    const div = document.createElement("div");
    div.className = "article";
    div.innerHTML = `
      <img src="${article.image}" alt="${article.title}">
      <h3>${article.title}</h3>
      <p>${article.date}</p>
    `;
    container.appendChild(div);

    const li = document.createElement("li");
    li.textContent = article.title;
    latestList.appendChild(li);
  });
}

function searchArticles() {
  const input = document.getElementById("searchInput").value.toLowerCase();
  const container = document.getElementById("articles");
  container.innerHTML = "";

  const filtered = articles.filter(article => article.title.toLowerCase().includes(input));

  filtered.forEach(article => {
    const div = document.createElement("div");
    div.className = "article";
    div.innerHTML = `
      <img src="${article.image}" alt="${article.title}">
      <h3>${article.title}</h3>
      <p>${article.date}</p>
    `;
    container.appendChild(div);
  });
}

function updateDateTime() {
  const now = new Date();
  const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
  document.getElementById("dateTime").textContent = now.toLocaleDateString('it-IT', options);
}